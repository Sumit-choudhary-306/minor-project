document.querySelector('.hamburger').addEventListener('click', () => {
    document.querySelector('.nav-links').classList.toggle('active');
});



// ----------------UPLOAD SECTION---------------
const uploadBtn = document.getElementById('Upload');
const viewBtn = document.getElementById('View');
const uploadSection = document.getElementById('upload-section');

uploadBtn.addEventListener('click', () => {
    if (uploadSection.style.display === "none" || uploadSection.style.display === "") {
        uploadSection.style.display = "block";
    } else {
        uploadSection.style.display = "none";
    }
});

viewBtn.addEventListener('click', () => {
    uploadSection.style.display = "none";
});

 
//    UPLOAD SECTION  //


document.getElementById("upload-button").addEventListener("click", function () {
    const progressBar = document.getElementById("progress-bar");
    const uploadProgress = document.getElementById("upload-progress");

    // Reset progress bar & make it visible
    progressBar.style.width = "0%";
    uploadProgress.style.display = "block";

    let progress = 0;
    const interval = setInterval(() => {
        if (progress >= 100) {
            clearInterval(interval);

            // Keep the progress bar visible for 4 seconds after completion
            setTimeout(() => {
                uploadProgress.style.display = "none";
            }, 200);
        } else {
            progress += 10; // Increase progress
            progressBar.style.width = progress + "%";
        }
    }, 300); // Total time to reach 100% = 4 seconds
});

// ------------------ Dark Mode -------------------

function toggleTheme() {
    const body = document.body;
    const currentTheme = body.getAttribute('data-theme');

    if (currentTheme === 'dark') {
        body.removeAttribute('data-theme');
        localStorage.setItem('theme', 'light');
    } else {
        body.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
    }
}

// Load saved theme preference
function loadTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.setAttribute('data-theme', 'dark');
    }
}

window.onload = loadTheme;