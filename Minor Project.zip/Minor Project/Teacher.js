// ---------------------- Hamburger Menu Toggle ----------------------
document.querySelector('.hamburger').addEventListener('click', () => {
    document.querySelector('.nav-links').classList.toggle('active');
});


//---------------- Login/Sign Up Button----------
// Function to redirect to the Login/Signup page
function redirectToLogin() {
    window.location.href = "form.html"; // Replace "login.html" with your actual login/signup page URL
}

// ---------------------- Upload Section Functionality ----------------------
// ---------------------- Upload Section Functionality ----------------------
const uploadBtn = document.getElementById('Upload');
const viewBtn = document.getElementById('View');
const uploadSection = document.getElementById('upload-section');
const fileInput = document.getElementById('file-input'); // File input field
const uploadMessage = document.getElementById('upload-message'); // Success message element

uploadBtn.addEventListener('click', () => {
    uploadSection.style.display = uploadSection.style.display === 'block' ? 'none' : 'block';
});

viewBtn.addEventListener('click', () => {
    uploadSection.style.display = 'none';
});

// Simulate file upload progress
document.getElementById('upload-button').addEventListener('click', () => {
    const progressBar = document.getElementById('progress-bar');
    const uploadProgress = document.getElementById('upload-progress');

    // Reset and show progress bar
    progressBar.style.width = '0%';
    uploadProgress.style.display = 'block';
    uploadMessage.style.display = 'none'; // Hide previous success message

    let progress = 0;
    const interval = setInterval(() => {
        if (progress >= 100) {
            clearInterval(interval);

            setTimeout(() => {
                uploadProgress.style.display = 'none'; // Hide progress bar after completion
                uploadMessage.style.display = 'block'; // Show success message
                uploadMessage.innerText = "File uploaded successfully!"; 

                fileInput.value = ""; // Clear file input field for new selection

                // Hide success message after 3 seconds
                setTimeout(() => {
                    uploadMessage.style.display = 'none';
                }, 2000);

            }, 1000); // Show success message after 1 second
        } else {
            progress += 10; // Increment progress
            progressBar.style.width = `${progress}%`;
        }
    }, 300); // Update progress every 300ms
});



// ---------------------- Dark Mode Toggle ----------------------
function toggleTheme() {
    const body = document.body;
    const currentTheme = body.getAttribute('data-theme');

    if (currentTheme === 'dark') {
        body.removeAttribute('data-theme');
        localStorage.setItem('theme', 'light');
    } else {
        body.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
    }
}

// Load saved theme preference on page load
function loadTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.setAttribute('data-theme', 'dark');
    }
}

window.addEventListener('load', loadTheme);

// ---------------------- Edit and Delete Functionality ----------------------
const dummyNotesList = document.querySelector('.dummy_notes');

dummyNotesList.addEventListener('click', (event) => {
    const target = event.target;

    // Delete Functionality
    if (target.classList.contains('fa-trash')) {
        const confirmDelete = confirm('Are you sure you want to delete this note?');
        if (confirmDelete) {
            const listItem = target.closest('li');
            listItem.remove(); // Remove the note from the DOM
        }
    }

    // Edit Functionality
    if (target.classList.contains('fa-edit')) {
        const listItem = target.closest('li');
        const link = listItem.querySelector('a');
        const currentText = link.textContent;

        // Create an input field for editing
        const input = document.createElement('input');
        input.type = 'text';
        input.value = currentText;

        // Replace link text with input field
        link.textContent = '';
        link.appendChild(input);
        input.focus();

        // Save changes on pressing Enter
        input.addEventListener('keyup', (e) => {
            if (e.key === 'Enter') {
                const newText = input.value.trim();
                link.textContent = newText || currentText; // Update or revert text
            }
        });

        // Save changes on losing focus
        input.addEventListener('blur', () => {
            const newText = input.value.trim();
            link.textContent = newText || currentText; // Update or revert text
        });
    }
});

// ---------------------- Filter Buttons for Notes ----------------------
document.addEventListener('DOMContentLoaded', () => {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const files = document.querySelectorAll('.dummy_note');

    // Function to filter notes by type
    function filterFiles(type) {
        files.forEach((file) => {
            const fileType = file.getAttribute('data-type');
            if (type === 'all' || fileType === type) {
                file.style.display = 'block'; // Show matching files
            } else {
                file.style.display = 'none'; // Hide non-matching files
            }
        });
    }

    // Add event listeners to filter buttons
    filterButtons.forEach((button) => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            filterButtons.forEach((btn) => btn.classList.remove('active'));

            // Add active class to the clicked button
            button.classList.add('active');

            // Get the filter type from the button's ID
            const filterType = button.id.replace('-btn', '');
            filterFiles(filterType); // Filter files
        });
    });

    // Show all files by default
    filterFiles('all');
});
// ---------------------------- Editable Profile ----------------------------
// Function to make profile details editable
function makeProfileEditable() {
    const profileDataElements = document.querySelectorAll('#profile-data');

    profileDataElements.forEach((element) => {
        element.addEventListener('click', () => {
            const originalText = element.textContent; // Store the original text
            const fieldName = element.textContent.split(':')[0].trim(); // Extract field name (e.g., "Name", "ID")

            // Create an input field
            const input = document.createElement('input');
            input.type = 'text';
            input.value = originalText.split(':')[1].trim(); // Extract current value
            input.style.width = '200px'; // Set input width
            input.style.padding = '5px'; // Add padding for better UX

            // Replace the text with the input field
            element.textContent = '';
            element.appendChild(input);
            input.focus();

            // Save changes on pressing Enter
            input.addEventListener('keyup', (e) => {
                if (e.key === 'Enter') {
                    const newValue = input.value.trim();
                    if (newValue) {
                        element.textContent = `${fieldName}: ${newValue}`; // Update the text
                    } else {
                        element.textContent = originalText; // Revert to original text if input is empty
                    }
                }
            });

            // Save changes on losing focus
            input.addEventListener('blur', () => {
                const newValue = input.value.trim();
                if (newValue) {
                    element.textContent = `${fieldName}: ${newValue}`; // Update the text
                } else {
                    element.textContent = originalText; // Revert to original text if input is empty
                }
            });
        });
    });
}

// Function to make profile photo editable
function makeProfilePhotoEditable() {
    const profilePhotoContainer = document.querySelector('#Left'); // Container for the profile photo
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*'; // Allow only image files
    fileInput.style.display = 'none'; // Hide the file input

    // Add file input to the DOM
    document.body.appendChild(fileInput);

    // Function to handle profile photo click
    function handleProfilePhotoClick() {
        fileInput.click();
    }

    // Attach event listener to the profile photo container
    profilePhotoContainer.addEventListener('click', (event) => {
        if (event.target.id === 'profile') {
            handleProfilePhotoClick();
        }
    });

    // Handle file selection
    fileInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                // Create a new image element
                const newImage = new Image();
                newImage.src = e.target.result;

                // Apply specific CSS styles to the new image
                newImage.style.width = '200px'; // Set width
                newImage.style.height = '200px'; // Set height
                newImage.style.borderRadius = '50%'; // Set border radius
                newImage.style.border = '2px solid #ccc'; // Set border (optional)
                newImage.style.margin = '70px'; // Set margin
                newImage.id = 'profile'; // Ensure the ID remains the same

                // Replace the old image with the new image
                const oldImage = document.getElementById('profile');
                oldImage.parentNode.replaceChild(newImage, oldImage);

                // Save the new image to localStorage
                saveProfilePhoto(e.target.result);
            };
            reader.readAsDataURL(file); // Read the selected file as a data URL
        }
    });
}

// Save profile photo to localStorage
function saveProfilePhoto(newPhoto) {
    localStorage.setItem('profilePhoto', newPhoto);
}

// Load saved profile photo
function loadProfilePhoto() {
    const savedPhoto = localStorage.getItem('profilePhoto');
    if (savedPhoto) {
        const profilePhotoContainer = document.querySelector('#Left'); // Container for the profile photo
        const newImage = new Image();
        newImage.src = savedPhoto;

        // Apply specific CSS styles to the new image
        newImage.style.width = '200px'; // Set width
        newImage.style.height = '200px'; // Set height
        newImage.style.borderRadius = '50%'; // Set border radius
        newImage.style.border = '2px solid #ccc'; // Set border (optional)
        newImage.style.margin = '70px'; // Set margin
        newImage.id = 'profile'; // Ensure the ID remains the same

        // Replace the old image with the new image
        const oldImage = document.getElementById('profile');
        oldImage.parentNode.replaceChild(newImage, oldImage);
    }
}

// Call the functions to make profiles and profile photo editable
makeProfileEditable();
makeProfilePhotoEditable();
loadProfilePhoto(); // Load saved profile photo on page load


// ---------------------------- Seach Bar ------------------------
// ---------------------------- Search Functionality ----------------------------
function makeSearchBarFunctional() {
    const searchBar = document.getElementById('search-bar');
    const dummyNotes = document.querySelectorAll('.dummy_note');

    searchBar.addEventListener('input', () => {
        const searchTerm = searchBar.value.trim().toLowerCase(); // Get the search term

        dummyNotes.forEach((note) => {
            const noteText = note.textContent.toLowerCase(); // Get the text content of the note
            if (noteText.includes(searchTerm)) {
                note.style.display = 'block'; // Show the note if it matches the search term
            } else {
                note.style.display = 'none'; // Hide the note if it doesn't match
            }
        });
    });
}

// Call the function to make the search bar functional
makeSearchBarFunctional();